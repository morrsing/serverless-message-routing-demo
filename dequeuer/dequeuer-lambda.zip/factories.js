'use strict';

var preconditionsFactory = function preconditionsFactory(callback) {
  return function (kinesisStreamId, kinesisShardId) {
    if (typeof kinesisStreamId === 'undefined') {
      callback('InvalidStreamId');
      return false;
    }

    if (typeof kinesisShardId === 'undefined') {
      callback('InvalidShardId');
      return false;
    }
    return true;
  };
};

module.exports = {
  preconditionsFactory: preconditionsFactory
};