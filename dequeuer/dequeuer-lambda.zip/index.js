'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var _process$env = process.env,
    KINESIS_STREAM_ID = _process$env.KINESIS_STREAM_ID,
    KINESIS_SHARD_ID = _process$env.KINESIS_SHARD_ID;

var _require = require('./factories'),
    preconditionsFactory = _require.preconditionsFactory;

var client = require('./kinesis-client');

var handler = function handler(event, context, callback) {

  var checkPreconditions = preconditionsFactory(callback);
  var fromTimestamp = parseInt(event.queryStringParameters.timestamp);

  if (checkPreconditions(KINESIS_STREAM_ID, KINESIS_SHARD_ID, fromTimestamp)) {
    client.getShardIterator({
      ShardId: KINESIS_SHARD_ID,
      ShardIteratorType: 'AT_TIMESTAMP',
      StreamName: KINESIS_STREAM_ID,
      Timestamp: fromTimestamp
    }).then(function (shardIterator) {
      return client.consume(shardIterator);
    }).then(function (result) {
      var messages = result.Records.map(function (record) {
        try {
          return JSON.parse(record.Data.toString());
        } catch (err) {
          return {}; // Recommend useful error handling.
        }
      });

      var response = {
        statusCode: 200,
        headers: {},
        body: JSON.stringify(messages)
      };

      callback(null, response);
    }).catch(function (err) {
      callback(err);
    });
  }
};

exports.default = handler;