'use strict';

var AWS = require('aws-sdk');
if (typeof AWS.config.region === 'undefined') {
  AWS.config.region = process.env.REGION || 'us-east-1';
}

var kinesis = new AWS.Kinesis();

var readfromKinesis = function readfromKinesis(params) {
  return new Promise(function (resolve, reject) {
    kinesis.getRecords(params, function (err, data) {
      if (err) {
        reject(err);
      }
      resolve(data);
    });
  });
};

var getShardIterator = function getShardIterator(params) {
  return new Promise(function (resolve, reject) {
    kinesis.getShardIterator(params, function (err, data) {
      if (err) {
        reject(err);
      }
      resolve(data);
    });
  });
};

module.exports = {
  consume: readfromKinesis,
  getShardIterator: getShardIterator
};