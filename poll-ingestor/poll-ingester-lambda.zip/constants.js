'use strict';

var METHOD_REQUESTER_MAP = {
  GET: 'get',
  POST: 'post',
  PUT: 'put',
  DELETE: 'delete'
};

module.exports = {
  METHOD_REQUESTER_MAP: METHOD_REQUESTER_MAP
};