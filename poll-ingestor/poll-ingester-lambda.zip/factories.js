'use strict';

var includes = require('lodash/includes');

var _require = require('./constants'),
    METHOD_REQUESTER_MAP = _require.METHOD_REQUESTER_MAP;

var isValidMethod = function isValidMethod(method) {
  return includes(Object.keys(METHOD_REQUESTER_MAP), method);
};

var preconditionsFactory = function preconditionsFactory(callback) {
  return function (endpoint, method) {
    if (typeof endpoint === 'undefined') {
      callback('InvalidEndpoint');
      return false;
    }

    if (!isValidMethod(method)) {
      callback('InvalidRequestMethod');
      return false;
    }

    return true;
  };
};

module.exports = {
  preconditionsFactory: preconditionsFactory
};