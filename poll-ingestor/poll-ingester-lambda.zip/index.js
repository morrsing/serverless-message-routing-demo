'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var request = require('superagent');
var winston = require('winston');

var _require = require('./step-functions-client'),
    processRecord = _require.processRecord;

var _require2 = require('./constants'),
    METHOD_REQUESTER_MAP = _require2.METHOD_REQUESTER_MAP;

var _require3 = require('./factories'),
    preconditionsFactory = _require3.preconditionsFactory;

var _process$env = process.env,
    ENDPOINT = _process$env.ENDPOINT,
    METHOD = _process$env.METHOD;


var handler = function handler(event, context, callback) {
  winston.log('info', 'Poll ingester invoked.');
  var checkPreconditions = preconditionsFactory(callback);

  if (checkPreconditions(ENDPOINT, METHOD)) {
    var method = METHOD_REQUESTER_MAP[METHOD];
    request[method](ENDPOINT).end(function (err, res) {
      if (err) {
        callback(err);
        return;
      }

      var messages = JSON.parse(res.text);
      messages.forEach(function (message) {
        winston.log('info', message);
      });

      Promise.all(messages.map(processRecord)).then(function (result) {
        callback(null, result);
      }).catch(function (err) {
        callback(err);
      });
    });
  }
};

exports.default = handler;