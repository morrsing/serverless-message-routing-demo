'use strict';

var responseHandlerFactory = function responseHandlerFactory(callback) {
  return function (err) {
    if (err) {
      callback('ERROR');
    } else {
      callback(null, 'SUCCESS');
    }
  };
};

var preconditionsFactory = function preconditionsFactory(callback) {
  return function (endpoint) {
    if (typeof endpoint === 'undefined') {
      callback('InvalidEndpoint');
      return false;
    }
    return true;
  };
};

module.exports = {
  responseHandlerFactory: responseHandlerFactory,
  preconditionsFactory: preconditionsFactory
};