'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var request = require('superagent');

var ENDPOINT = process.env.ENDPOINT;

var _require = require('./factories'),
    responseHandlerFactory = _require.responseHandlerFactory,
    preconditionsFactory = _require.preconditionsFactory;

var handler = function handler(event, context, callback) {
  var handleResponse = responseHandlerFactory(callback);
  var checkPreconditions = preconditionsFactory(callback);

  checkPreconditions(ENDPOINT);

  request.post(ENDPOINT).send([event.message]).set('accept', 'json').end(handleResponse);
};

exports.default = handler;