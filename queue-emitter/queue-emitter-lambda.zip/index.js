'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var _process$env = process.env,
    KINESIS_STREAM_ID = _process$env.KINESIS_STREAM_ID,
    KINESIS_SHARD_ID = _process$env.KINESIS_SHARD_ID;

var _require = require('./factories'),
    preconditionsFactory = _require.preconditionsFactory;

var client = require('./kinesis-client');

var handler = function handler(event, context, callback) {
  var checkPreconditions = preconditionsFactory(callback);

  if (checkPreconditions(KINESIS_STREAM_ID, KINESIS_SHARD_ID)) {
    client.produce({
      Data: JSON.stringify(event.message),
      PartitionKey: KINESIS_SHARD_ID,
      StreamName: KINESIS_STREAM_ID
    }).then(function (result) {
      callback(null, result);
    }).catch(function (err) {
      callback(err);
    });
  }
};

exports.default = handler;