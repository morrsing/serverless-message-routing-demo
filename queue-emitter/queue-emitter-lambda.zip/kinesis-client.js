'use strict';

var AWS = require('aws-sdk');
if (typeof AWS.config.region === 'undefined') {
  AWS.config.region = process.env.REGION || 'us-east-1';
}

var kinesis = new AWS.Kinesis();

var sendToKinesis = function sendToKinesis(params) {
  return new Promise(function (resolve, reject) {
    kinesis.putRecord(params, function (err, data) {
      if (err) {
        reject(err);
      }
      resolve(data);
    });
  });
};

module.exports = {
  produce: sendToKinesis
};