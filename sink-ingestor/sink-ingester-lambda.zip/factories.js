'use strict';

var preconditionsFactory = function preconditionsFactory(callback) {
  return function (stateMachineArn) {
    if (typeof stateMachineArn === 'undefined') {
      callback('InvalidStateMachineArn');
      return false;
    }

    return true;
  };
};

module.exports = {
  preconditionsFactory: preconditionsFactory
};