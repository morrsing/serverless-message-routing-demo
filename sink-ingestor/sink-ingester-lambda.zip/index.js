'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _require = require('./step-functions-client'),
    processRecord = _require.processRecord;

var _require2 = require('./factories'),
    preconditionsFactory = _require2.preconditionsFactory;

var STATE_MACHINE_ARN = process.env.STATE_MACHINE_ARN;


var fixApiGatewayObjectTreatment = function fixApiGatewayObjectTreatment(mungedRecord) {
  var correctedRecord = mungedRecord.replace(/=/g, '":"');
  correctedRecord = correctedRecord.replace(/{/g, '{"');
  correctedRecord = correctedRecord.replace(/}/g, '"}');
  correctedRecord = correctedRecord.replace(/, /g, ',');
  correctedRecord = correctedRecord.replace(/,/g, '","');
  return correctedRecord;
};

var handler = function handler(event, context, callback) {
  var checkPreconditions = preconditionsFactory(callback);

  if (checkPreconditions(STATE_MACHINE_ARN)) {
    var messages = event.Records.map(function (record) {
      return Buffer.from(record.kinesis.data, 'base64').toString();
    }).map(fixApiGatewayObjectTreatment).map(JSON.parse);

    Promise.all(messages.map(processRecord)).then(function (result) {
      callback(null, result);
    }).catch(function (err) {
      callback(err);
    });
  }
};

exports.default = handler;