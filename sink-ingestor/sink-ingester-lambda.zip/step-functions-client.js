'use strict';

var AWS = require('aws-sdk');
if (typeof AWS.config.region === 'undefined') {
  AWS.config.region = process.env.REGION || 'us-east-1';
}

var STATE_MACHINE_ARN = process.env.STATE_MACHINE_ARN;


var StepFunctions = new AWS.StepFunctions();

var processRecord = function processRecord(record) {
  return new Promise(function (resolve, reject) {
    var params = {
      stateMachineArn: STATE_MACHINE_ARN,
      input: JSON.stringify({ message: record })
    };

    StepFunctions.startExecution(params, function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

module.exports = {
  processRecord: processRecord
};