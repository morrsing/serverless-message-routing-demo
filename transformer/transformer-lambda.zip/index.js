"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var transform = function transform(msg) {
  return Object.assign({}, msg, {
    additionalValue: true
  });
};

var handler = function handler(event, context, callback) {

  callback(null, { message: transform(event.message) });
};

exports.default = handler;